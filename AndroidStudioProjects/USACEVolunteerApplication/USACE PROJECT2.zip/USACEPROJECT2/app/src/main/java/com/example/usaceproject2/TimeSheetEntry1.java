package com.example.usaceproject2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TimeSheetEntry1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_sheet_entry1);
    }
}